package com.sae32.scanner;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class NmapScanner implements ToolScanner {

    private final String nmapBinary = "nmap";

    @Override
    public String getName() {
        return "nmap";
    }

    @Override
    public List<Finding> scanTarget(String target, String port) throws Exception {
        List<Finding> results = new ArrayList<>();

        // Build Nmap command
        List<String> command = new ArrayList<>();
        command.add(nmapBinary);
        command.add("-sV"); // version detection

        if (port != null && !port.isBlank()) {
            command.add("-p");
            command.add(port); // single port (ex: "80")
        }

        command.add(target);

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process process = pb.start();

        StringBuilder output = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
            }
        }

        int exitCode = process.waitFor();

        Finding finding = new Finding();
        finding.setSourceTool(getName());
        finding.setSeverity("INFO");
        finding.setTitle("Résultat Nmap");
        finding.setDescription("Résultat brut de Nmap sur la cible.");
        finding.setTarget(target);
        finding.setDetails(
                "Commande exécutée : " + String.join(" ", command)
                        + System.lineSeparator()
                        + "Exit code : " + exitCode
                        + System.lineSeparator()
                        + output
        );

        results.add(finding);
        return results;
    }
}
