package com.sae32.scanner;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ScanApp {

    private final DatabaseManager dbManager;

    /**
     * Registry of tools (name -> instance).
     * Tools are listed once here, then enabled/disabled via ENABLED_TOOLS.
     */
    private final Map<String, ToolScanner> toolRegistry;

    /**
     * Tools to run (easy to change without touching the loop logic).
     * Just add/remove names here.
     */
    private static final List<String> ENABLED_TOOLS = List.of(
            "nmap",
            "masscan",
            "nikto",
            "whatweb"
    );

    public ScanApp() {
        this.dbManager = new DatabaseManager();

        // Keep insertion order (nice for logs)
        this.toolRegistry = new LinkedHashMap<>();
        registerTool(new NmapScanner());
        registerTool(new MasscanScanner());
        registerTool(new NiktoScanner());
        registerTool(new WhatWebScanner());
    }

    private void registerTool(ToolScanner tool) {
        toolRegistry.put(tool.getName(), tool);
    }

    private List<ToolScanner> getEnabledScanners() {
        List<ToolScanner> enabled = new ArrayList<>();
        for (String name : ENABLED_TOOLS) {
            ToolScanner tool = toolRegistry.get(name);
            if (tool == null) {
                System.err.println("⚠ Outil inconnu dans ENABLED_TOOLS : " + name + " (ignoré)");
                continue;
            }
            enabled.add(tool);
        }
        return enabled;
    }

    public static void main(String[] args) {
        ScanApp app = new ScanApp();
        try {
            app.processPendingScans();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Récupère les scans en attente dans la BDD et lance les outils activés sur chaque cible.
     * Le champ "ports" (optionnel) permet de limiter le scan à un port unique.
     */
    public void processPendingScans() throws Exception {
        dbManager.connect();

        List<ScannerRun> pending = dbManager.getPendingScans();
        if (pending.isEmpty()) {
            System.out.println("Aucun scan en attente.");
            dbManager.close();
            return;
        }

        List<ToolScanner> scanners = getEnabledScanners();
        System.out.println("Scans en attente : " + pending.size());
        System.out.println("Outils activés : " + scanners.stream().map(ToolScanner::getName).toList());

        for (ScannerRun run : pending) {
            String target = run.getTarget();
            String port = run.getPorts(); // <-- requires ScannerRun to have getPorts()

            System.out.println("Traitement du scan #" + run.getId() + " sur " + target
                    + (port != null && !port.isBlank() ? " (port=" + port + ")" : ""));

            dbManager.updateScanStatus(run.getId(), "running");

            List<Finding> allFindings = new ArrayList<>();

            for (ToolScanner scanner : scanners) {
                try {
                    System.out.println("  -> Lancement de " + scanner.getName() + " sur " + target
                            + (port != null && !port.isBlank() ? ":" + port : ""));

                    List<Finding> findings = scanner.scanTarget(target, port);

                    for (Finding f : findings) {
                        f.setScannerRunId(run.getId());
                        f.setSourceTool(scanner.getName());
                    }
                    allFindings.addAll(findings);

                } catch (Exception e) {
                    System.err.println("Erreur pendant le scan avec " + scanner.getName() + " : " + e.getMessage());
                }
            }

            if (!allFindings.isEmpty()) {
                dbManager.saveFindings(allFindings, run.getId());
                System.out.println("  -> " + allFindings.size() + " vulnérabilité(s) enregistrée(s).");
            } else {
                System.out.println("  -> Aucun résultat trouvé (ou parsing non implémenté).");
            }

            dbManager.updateScanStatus(run.getId(), "done");
            System.out.println("Scan #" + run.getId() + " terminé.");
        }

        dbManager.close();
    }
}
