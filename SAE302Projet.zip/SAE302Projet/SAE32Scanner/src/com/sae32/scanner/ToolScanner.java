package com.sae32.scanner;

import java.util.List;

public interface ToolScanner {

    String getName();
    List<Finding> scanTarget(String target, String port) throws Exception;
}
