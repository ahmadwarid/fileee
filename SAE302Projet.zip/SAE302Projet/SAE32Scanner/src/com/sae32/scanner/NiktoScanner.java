package com.sae32.scanner;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class NiktoScanner implements ToolScanner {

    private final String niktoBinary = "nikto";

    @Override
    public String getName() {
        return "nikto";
    }

    /**
     * Nikto is an HTTP scanner. If a single port is provided, Nikto targets:
     *   http://<target>:<port>
     * Otherwise it targets:
     *   http://<target>
     *
     * Timeout: 60 seconds to avoid blocking.
     */
    @Override
    public List<Finding> scanTarget(String target, String port) throws Exception {
        List<Finding> results = new ArrayList<>();

        String url = (port != null && !port.isBlank())
                ? "http://" + target + ":" + port
                : "http://" + target;

        List<String> command = new ArrayList<>();
        command.add(niktoBinary);
        command.add("-host");
        command.add(url);
        command.add("-ask");
        command.add("no"); // prevent interactive questions

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process process = pb.start();

        StringBuilder output = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
            }
        }

        boolean finished = process.waitFor(60, TimeUnit.SECONDS);
        if (!finished) {
            process.destroyForcibly();
            throw new RuntimeException("Nikto a dépassé le délai (timeout 60s).");
        }

        int exitCode = process.exitValue();

        Finding f = new Finding();
        f.setSourceTool(getName());
        f.setSeverity("INFO");
        f.setTitle("Résultat Nikto");
        f.setDescription("Résultat brut de Nikto sur la cible.");
        f.setTarget(target);
        f.setDetails(
                "Commande exécutée : " + String.join(" ", command)
                        + System.lineSeparator()
                        + "Exit code : " + exitCode
                        + System.lineSeparator()
                        + output
        );
        results.add(f);

        return results;
    }
}
