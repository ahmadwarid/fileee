package com.sae32.scanner;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class WhatWebScanner implements ToolScanner {

    private final String whatwebBinary = "whatweb";

    @Override
    public String getName() {
        return "whatweb";
    }

    /**
     * WhatWeb is an HTTP fingerprinting tool.
     * If a single port is provided, it targets: http://<target>:<port>
     * Otherwise it targets: http://<target>
     */
    @Override
    public List<Finding> scanTarget(String target, String port) throws Exception {
        List<Finding> results = new ArrayList<>();

        String url = (port != null && !port.isBlank())
                ? "http://" + target + ":" + port
                : "http://" + target;

        List<String> command = new ArrayList<>();
        command.add(whatwebBinary);
        command.add(url);

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process process = pb.start();

        StringBuilder output = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
            }
        }

        int exitCode = process.waitFor();

        Finding f = new Finding();
        f.setSourceTool(getName());
        f.setSeverity("INFO");
        f.setTitle("Résultat WhatWeb");
        f.setDescription("Résultat brut de WhatWeb sur la cible.");
        f.setTarget(target);
        f.setDetails(
                "Commande exécutée : " + String.join(" ", command)
                        + System.lineSeparator()
                        + "Exit code : " + exitCode
                        + System.lineSeparator()
                        + output
        );
        results.add(f);

        return results;
    }
}
