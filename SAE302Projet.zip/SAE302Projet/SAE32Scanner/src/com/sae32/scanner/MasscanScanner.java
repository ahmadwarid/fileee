package com.sae32.scanner;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MasscanScanner implements ToolScanner {

    private final String masscanBinary = "masscan";

    @Override
    public String getName() {
        return "masscan";
    }

    /**
     * If port is provided (single port), runs: masscan <target> -p<port> --rate 1000
     * Otherwise, runs the default scan on ports 1-1000.
     */
    @Override
    public List<Finding> scanTarget(String target, String port) throws Exception {
        List<Finding> results = new ArrayList<>();

        List<String> command = new ArrayList<>();
        command.add(masscanBinary);
        command.add(target);

        if (port != null && !port.isBlank()) {
            command.add("-p" + port); // single port (ex: "80")
        } else {
            command.add("--ports");
            command.add("1-1000");
        }

        command.add("--rate");
        command.add("1000");

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process process = pb.start();

        StringBuilder output = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
            }
        }

        int exitCode = process.waitFor();

        Finding f = new Finding();
        f.setSourceTool(getName());
        f.setSeverity("INFO");
        f.setTitle("Résultat Masscan");
        f.setDescription("Résultat brut de Masscan sur la cible.");
        f.setTarget(target);
        f.setDetails(
                "Commande exécutée : " + String.join(" ", command)
                        + System.lineSeparator()
                        + "Exit code : " + exitCode
                        + System.lineSeparator()
                        + output
        );
        results.add(f);

        return results;
    }
}
