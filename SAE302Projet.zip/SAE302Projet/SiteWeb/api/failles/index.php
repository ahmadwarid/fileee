<?php
require_once("../config.php");

$ip = $_GET["ip"] ?? "";
$ip = trim($ip);

if ($ip === "") {
    echo json_encode([]);
    exit;
}

// On récupère toutes les findings pour cette IP
$sql = "
    SELECT
        f.id,
        f.target       AS ip,
        r.ports        AS port,
        f.title        AS type,
        f.severity,
        f.description
    FROM findings f
    LEFT JOIN scanner_runs r ON r.id = f.scanner_run_id
    WHERE f.target = :ip
    ORDER BY f.created_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute([":ip" => $ip]);
$rows = $stmt->fetchAll();

$result = [];
foreach ($rows as $r) {
    $result[] = [
        "id"          => (int)$r["id"],
        "ip"          => $r["ip"],
        "port"        => $r["port"], // null si aucun port n'a été défini
        "type"        => $r["type"],
        "risque"      => severityToRisque($r["severity"]),
        "description" => $r["description"],
    ];
}

echo json_encode($result);
