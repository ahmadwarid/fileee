package com.example.sae302;

/**
 * Représente une faille (élément) renvoyée par l'API.
 */
public class VulnItem {
    public int id;
    public String ip;
    public String type;
    public String risque;

    public VulnItem(int id, String ip, String type, String risque) {
        this.id = id;
        this.ip = ip;
        this.type = type;
        this.risque = risque;
    }

    // Affichage dans la ListView (ArrayAdapter utilise toString())
    @Override
    public String toString() {
        return "[#" + id + "] " + ip + " - " + type + " (" + risque + ")";
    }
}
