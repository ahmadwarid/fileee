package com.example.sae302;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Écran principal : affiche la liste "Toutes les failles"
 * en récupérant l'API /api/failles/all.php
 */
public class MainActivity extends AppCompatActivity {

    /**
     * IMPORTANT :
     * - Android Emulator + port forwarding (PC -> Kali) : 10.0.2.2
     * - Si tu utilises une IP LAN, remplace 10.0.2.2 par l'IP réelle du serveur
     */
    private static final String API_BASE = "http://10.0.2.2:8080/api/failles";

    private ListView listView;
    private ArrayList<VulnItem> items = new ArrayList<>();
    private ArrayAdapter<VulnItem> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Layout: res/layout/activity_main.xml (contient un ListView id=listView)
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                items
        );
        listView.setAdapter(adapter);

        // Quand l'utilisateur clique sur une faille, ouvrir le détail
        listView.setOnItemClickListener((parent, view, position, id) -> {
            VulnItem selected = items.get(position);

            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("vuln_id", selected.id);
            startActivity(intent);
        });

        // Charger la liste au lancement
        new FetchAllTask().execute(API_BASE + "/all.php");
    }

    /**
     * AsyncTask qui récupère la liste des failles depuis /all.php
     * et remplit la ListView.
     */
    private class FetchAllTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            StringBuilder result = new StringBuilder();

            try {
                URL url = new URL(urls[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader =
                        new BufferedReader(new InputStreamReader(conn.getInputStream()));

                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                reader.close();
                return result.toString();

            } catch (Exception e) {
                return "ERROR: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (response.startsWith("ERROR")) {
                Toast.makeText(MainActivity.this, response, Toast.LENGTH_LONG).show();
                return;
            }

            try {
                // all.php renvoie un tableau JSON: [ {...}, {...} ]
                JSONArray arr = new JSONArray(response);

                items.clear();

                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);

                    int id = o.optInt("id");
                    String ip = o.optString("ip", "-");
                    String type = o.optString("type", "-");
                    String risque = o.optString("risque", "-");

                    items.add(new VulnItem(id, ip, type, risque));
                }

                adapter.notifyDataSetChanged();

                if (items.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Aucune faille trouvée.", Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Parse error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
